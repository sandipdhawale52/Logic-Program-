#include<stdio.h>

int main()
{
    char ch1 = 'a';
    char ch2 = 'A';
    char ch3 = '0';

    char ch4 = 'z';
    char ch5 = 'Z';
    char ch6 = '9';


    printf("Character representation is %c and its ASCII value is : %d\n",ch1,ch1);
    printf("Character representation is %c and its ASCII value is : %d\n",ch2,ch2);
    printf("Character representation is %c and its ASCII value is : %d\n",ch3,ch3);
    printf("Character representation is %c and its ASCII value is : %d\n",ch4,ch4);
    printf("Character representation is %c and its ASCII value is : %d\n",ch5,ch5);
    printf("Character representation is %c and its ASCII value is : %d\n",ch6,ch6);

    return 0;
}